cell = 10;
replication = 30;
numTesting = 50;
numWord = 2000; %29717;

trainingAccuracy = zeros(replication,10);
testingAccuracy = zeros(replication,10);
avgTraining = zeros(cell,1);
stdTraining = zeros(cell,1);
avgTesting = zeros(cell,1);
stdTesting = zeros(cell,1);

for M = 1:cell
    N = M*10;
    for rep = 1:replication
        sample = 1:198;
        sample = sample(randperm(198));

        X=bagofword(sample,:);
        Y=sentiment(sample,:);

        cntXbyY = ones(numWord,2)/1000;
        for i = 1:numWord
            for j=1:N
                if X(j,i) >= 1 
                    cntXbyY(i,Y(j)+1)=cntXbyY(i,Y(j)+1)+1;
                end
            end
        end

        cntY = zeros(2,1);
        for j=1:N
            if Y(j) == 0
                cntY(1)=cntY(1)+1;
            else
                cntY(2)=cntY(2)+1;
            end
        end

        probsXbyY = zeros(numWord,2);
        for i = 1:numWord
            for j=1:2
                probsXbyY(i,j) = cntXbyY(i,j) / cntY(j);
            end
        end

        probsY = zeros(2);
        for j=1:2
            probsY(j) = cntY(j) / ( cntY(1) + cntY(2) );
        end


        probsSentiment = zeros(198,2);
        for i=1:198
            for k = 1:2
                probsSentiment(i,k) = 1;
                for j=1:numWord
                    if X(i,j) == 1 
                        probsSentiment(i,k) = probsSentiment(i,k) * probsXbyY(j,k);
                    else
                        probsSentiment(i,k) = probsSentiment(i,k) * (1-probsXbyY(j,k));
                    end
                end
                probsSentiment(i,k) = probsSentiment(i,k) * probsY(k);
            end
        end


        logProbsSentiment = zeros(198,2);
        for i=1:198
            for k = 1:2
                logProbsSentiment(i,k) = 0;
                for j=1:numWord
                    if X(i,j) == 1 
                        logProbsSentiment(i,k) = logProbsSentiment(i,k) + log( probsXbyY(j,k) );
                    else
                        logProbsSentiment(i,k) = logProbsSentiment(i,k) + log( 1-probsXbyY(j,k) );
                    end
                end
                logProbsSentiment(i,k) = logProbsSentiment(i,k) + log( probsY(k) );
            end
        end

        estSentiment = zeros(198,1);
        for i = 1:198
            if probsSentiment(i,1) > probsSentiment(i,2) 
                estSentiment(i) = 0;
            else
                estSentiment(i) = 1;
            end
        end

        cntCorrect = 0;
        for i = 1:N
            if estSentiment(i) == Y(i)
                cntCorrect = cntCorrect + 1;
            end
        end
        trainingAccuracy(rep,M) = cntCorrect / N;

        cntCorrect = 0;
        for i = (N+1):(N+numTesting)
            if estSentiment(i) == Y(i)
                cntCorrect = cntCorrect + 1;
            end
        end
        testingAccuracy(rep,M) = cntCorrect / numTesting;
    end
    avgTraining(M) = mean(trainingAccuracy(:,M));
    avgTesting(M) = mean(testingAccuracy(:,M));
    stdTraining(M) = std(trainingAccuracy(:,M));
    stdTesting(M) = std(testingAccuracy(:,M));
end
figure
errorbar(avgTraining,stdTraining/sqrt(replication));
hold on;
errorbar(avgTesting,stdTesting/sqrt(replication),'r');
