mu = [0 0];
mu2 = [2 2];
Sigma = [.25 .3; .3 1];
x1 = -3:.2:5; x2 = -6:.2:7;
[X1,X2] = meshgrid(x1,x2);
F = mvnpdf([X1(:) X2(:)],mu,Sigma);
F2 = mvnpdf([X1(:) X2(:)],mu2,Sigma);
F = reshape(F,length(x2),length(x1));
F2 = reshape(F2,length(x2),length(x1));

mvncdf([0 0],[1 1],mu,Sigma);
contour(x1,x2,F,[.0001 .001 .01 .05:.1:.95 .99 .999 .9999]);
hold on
contour(x1,x2,F2,[.0001 .001 .01 .05:.1:.95 .99 .999 .9999]);
xlabel('x1'); ylabel('x2');

