x1 = 0:.1:4; x2 = -.5:.1:3;
[X1,X2] = meshgrid(x1,x2);

mu = [1 1];
Sigma = [.1 0; 0 .3];
F = mvnpdf([X1(:) X2(:)],mu,Sigma);
F = reshape(F,length(x2),length(x1));

mu2 = [2.5 1];
Sigma2 = [.3 0; 0 .1];
[X1,X2] = meshgrid(x1,x2);
F2 = mvnpdf([X1(:) X2(:)],mu2,Sigma2);
F2 = reshape(F2,length(x2),length(x1));

figure
axis([-3 3 -3 3 0 .4])
xlabel('x1'); ylabel('x2'); zlabel('Probability Density');
surf(x1,x2,F);
hold on;

surf(x1,x2,F2);
hold on;

