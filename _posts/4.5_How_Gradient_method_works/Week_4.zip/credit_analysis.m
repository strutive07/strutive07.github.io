% x=0.01:0.01:0.99;
% y=-log(1./x(:)-1);
% 
% % % % % % % % % % 
% 
% X=credit(:,15);
% X=X+0.0001;
% X_log=log(X);
% Y=credit(:,17);
% 
% X_reg=ones(size(X,1),2);
% X_reg(:,2)=X(:);
% theta = inv(transpose(X_reg(:,1:2))*X_reg(:,1:2))*transpose(X_reg(:,1:2))*Y;
% Y_est = X_reg(:,1:2)*theta;
% 
% [Q,p]=fit_logistic(X,Y);
% 
% figure
% h=scatter(X,Y,10);
% set(h(1),'MarkerFaceColor','b')
% set(h(1),'MarkerEdgeColor','b')
% hold on
% h1=scatter(X,Y_est,10);
% set(h1(1),'MarkerFaceColor','r')
% set(h1(1),'MarkerEdgeColor','r')
% hold on
% h2=scatter(X,Q,10);
% set(h2(1),'MarkerFaceColor','g')
% set(h2(1),'MarkerEdgeColor','g')
% 
% figure
% h=scatter(X_log,Y,10);
% set(h(1),'MarkerFaceColor','b')
% set(h(1),'MarkerEdgeColor','b')
% hold on
% h1=scatter(X_log,Y_est,10);
% set(h1(1),'MarkerFaceColor','r')
% set(h1(1),'MarkerEdgeColor','r')
% hold on
% h2=scatter(X_log,Q,10);
% set(h2(1),'MarkerFaceColor','g')
% set(h2(1),'MarkerEdgeColor','g')
% hold on
% 
% % % % % % % % % % 
% 
% theta = 0.01:0.001:0.99;
% y=5*theta(:)-log(1+exp(5*theta(:)));
% figure
% plot(theta,y);

%%%%%%%%%%%%%%%%

x=0.01:0.01:3;
y_exp=exp(x(:));
y_tal_exp=zeros(size(x,2),1);
for i = 1:size(x,2)
    y_tal_exp(i)=1;
    for j = 1:2
        y_tal_exp(i)=y_tal_exp(i)+1/factorial(j)*(x(i)-0).^j;
    end
end

figure
h1=plot(x,y_exp);
set(h1(1),'color','r')
hold on;
h2=plot(x,y_tal_exp);
set(h2(1),'color','b')


y_log=log(x(:));
y_tal_log=zeros(size(x,2),1);
a=0.5;
for i = 1:size(x,2)
    y_tal_log(i)=log(a);
    for j = 1:8
        y_tal_log(i)=y_tal_log(i)+(-1).^(j+1)*(1/a.^j)/factorial(j)*(x(i)-a).^j;
    end
end

figure
h1=plot(x,y_log);
set(h1(1),'color','r')
hold on;
h2=plot(x,y_tal_log);
set(h2(1),'color','b')





