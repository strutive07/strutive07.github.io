X=X(:,1:2);

t1 = inv(transpose(X(:,1:2))*X(:,1:2))*transpose(X(:,1:2))*Y;

itr = 1000;
d = 2;

t2 = zeros(itr,d);
t2(1,:) = [1 1];
h=0.00001;
for i = 2:itr
    for j = 1:d
        deriv = 0;
        for k = 1:size(X,1)
            deriv = deriv + 2*(Y(k)-X(k,:)*t2(i-1,:)')*X(k,j);
        end
        t2(i,j)=t2(i-1,j)+h*deriv;
    end
end

