function [ derivX1, derivX2 ] = RosenbrockDeriv( x1, x2 )
    
%     derivX1 = -2*(1-x1)+2*100*(x2-x1.^2)*-2;
%     derivX2 = 2*100*(x2-x1.^2);

    derivX1 = 400*x1*(x1^2-x2)+2*(x1-1);
    derivX2 = -200*(x1^2-x2);

end

