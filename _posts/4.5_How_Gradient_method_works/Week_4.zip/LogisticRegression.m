cell = 10;
replication = 5;
numTesting = 50;
numWord = 100; %29717;

trainingAccuracy = zeros(replication,10);
testingAccuracy = zeros(replication,10);
avgTraining = zeros(cell,1);
stdTraining = zeros(cell,1);
avgTesting = zeros(cell,1);
stdTesting = zeros(cell,1);

h=0.5;
threshold=0.1;
        
for M = 1:cell
    N = M*10;
    for rep = 1:replication
        sample = 1:198;
        sample = sample(randperm(198));

        numFeatures = numWord+1;
        X=ones(size(sample,2),numFeatures);
        X(:,2:numFeatures)=bagofword(sample,1:numWord);
        Y=sentiment(sample,:);
        
        theta = ones(numFeatures,1);
        itr = 500;
        
        cntItr = 0;
        for k = 1:itr
            thetanew = zeros(numFeatures,1);
            for i = 1:numFeatures
                temp = 0;
                for j = 1:N
                    Xtheta = X(j,:) * theta;
                    temp = temp + X(j,i) * ( Y(j) - exp( Xtheta ) / ( 1 + exp(Xtheta) ) );
                end
                temp = temp * h;
                thetanew(i) = theta(i) + temp;
            end
            diff = sum(abs(theta-thetanew));
            if diff/(sum(abs(theta))) < threshold
                break;
            end
            cntItr = cntItr + 1;
            theta = thetanew;
        end
        disp('Gradient Ascent Itr : ');
        disp(cntItr);
                
        probsSentiment = zeros(198,2);
        for i=1:198
            Xtheta = X(i,:) * theta;
            probsSentiment(i,1) = 1 / ( 1 + exp(Xtheta) );
            probsSentiment(i,2) = 1 - 1 / ( 1 + exp(Xtheta) );
        end

        estSentiment = zeros(198,1);
        for i = 1:198
            if probsSentiment(i,1) > probsSentiment(i,2) 
                estSentiment(i) = 0;
            else
                estSentiment(i) = 1;
            end
        end

        cntCorrect = 0;
        for i = 1:N
            if estSentiment(i) == Y(i)
                cntCorrect = cntCorrect + 1;
            end
        end
        trainingAccuracy(rep,M) = cntCorrect / N;

        cntCorrect = 0;
        for i = (N+1):(N+numTesting)
            if estSentiment(i) == Y(i)
                cntCorrect = cntCorrect + 1;
            end
        end
        testingAccuracy(rep,M) = cntCorrect / numTesting;
    end
    avgTraining(M) = mean(trainingAccuracy(:,M));
    avgTesting(M) = mean(testingAccuracy(:,M));
    stdTraining(M) = std(trainingAccuracy(:,M));
    stdTesting(M) = std(testingAccuracy(:,M));
end
errorbar(10*(1:cell),avgTraining,stdTraining/sqrt(replication));
hold on;
errorbar(10*(1:cell),avgTesting,stdTesting/sqrt(replication),'r');
xlabel('Number of Training Cases');
ylabel('Classification Accuracy');
legend('Training','Testing');
